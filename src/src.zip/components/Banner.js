import React from 'react'

const banner = () => {
  return (
    <div>banner</div>
  )
}

export default banner